package scala.reflect.macros

package object runtime {
  type Context = scala.reflect.macros.contexts.Context
}