package scala.tools.nsc.symtab

package object classfile {

  val ClassfileConstants = scala.reflect.internal.ClassfileConstants

}
